# Historical source provenance

## Main demo label
**Historical Replay — Publicly documented 2012 market-access incident**

Do not name the company in the main UI. If asked, the source appendix can identify the public SEC record.

Say:
> We reconstructed the decision pattern with synthetic local files based on an SEC record. These are not the company's original systems or documents.

## SEC-supported facts
The SEC record establishes that:
- a new router deployment did not reach one of eight servers;
- seven servers received the new code while one retained old behavior;
- an internal system generated 97 automated emails before market open referencing the router and an error;
- those emails were not designed as formal system alerts and were not acted on before market open;
- after market open the router sent millions of orders while handling 212 customer orders;
- the event produced more than 4 million executions, more than 397 million shares and a loss above $460 million over roughly 45 minutes.

## Official sources
SEC press release: https://www.sec.gov/newsroom/press-releases/2013-222  
SEC order: https://www.sec.gov/files/litigation/admin/2013/34-70694.pdf  
EDGAR HTML: https://www.sec.gov/Archives/edgar/data/1569391/000119312513401173/d613486dex101.htm

## Synthetic elements
All local filenames, SOP wording, human roles, countdown, simulator, tool outputs, evidence IDs and Resolve decisions are synthetic. Do not claim a historical human followed the exact Resolve sequence or that Resolve would certainly have prevented the loss.
