# Primary golden run — historical market-access replay

## Hook
**97 warnings. Nobody stopped the system.**

Replay starts at `09:25`, market open at `09:30`.

## Local synthetic facts
- 8 nodes expected on release `RLP-v2`;
- 7 are confirmed current;
- node 08 lacks a confirmed receipt / later proves old version;
- 97 pre-market anomaly messages reference the router;
- opening delay has a business cost;
- local market-access HOLD exists and is reversible;
- exposing the system to live flow has asymmetric downside;
- HOLD requires human approval.

## First pass
Evidence Scout -> gathers deployment/anomaly evidence.  
Operations Planner -> assesses deployment and containment.  
Business Analyst -> assesses time/business pressure.

## Attractive initial candidate
`PROCEED_AND_MONITOR`

Why it seems plausible:
- most nodes look healthy;
- anomalies are not classified as critical alerts;
- opening delay costs money;
- no realized production loss exists yet.

## Falsifier
Challenges:
- one node is not independently verified;
- anomaly timing follows the deployment;
- absence of realized loss before exposure is weak evidence;
- downside of proceeding is not symmetric with downside of waiting.

## Judge #1
`INSUFFICIENT_EVIDENCE`

Exact gaps:
1. version on node 08;
2. origin correlation for the 97 anomalies;
3. whether HOLD is available/reversible;
4. local replay after isolation.

## Targeted second pass
`inspect_node_version(08)` -> old router version.  
`correlate_anomalies()` -> 97/97 -> node 08.  
`simulate_hold_and_isolation()` -> PASS.

## Revised candidate
`HOLD -> ISOLATE NODE 08 -> REDEPLOY -> LOCAL REPLAY -> VERIFY`

## Contract
Evidence PASS  
Authority HUMAN_REQUIRED  
Consequence PASS  
Reversibility PASS  
Rehearsal PASS  
Verification plan PASS

## Commit
Human clicks `APPROVE HOLD`.

Local simulator sets `market_access = HELD`, repairs node 08 in the synthetic state and runs replay.

## Verify
All 8 hashes match, replay is clean, hold remains controllable.

Final: `OUTCOME VERIFIED` -> `WATCH MODE`.

## Demo line
> The point isn't that an LLM predicts a historical failure. The point is that fragmented evidence never becomes permission by accident.
