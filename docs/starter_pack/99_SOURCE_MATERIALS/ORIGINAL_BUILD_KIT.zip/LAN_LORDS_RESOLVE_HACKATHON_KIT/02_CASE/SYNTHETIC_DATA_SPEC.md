# Synthetic data spec

Build the actual files on the hackathon day.

```text
cases/market_access/
├── objective.json
├── deployment/expected_release.json
├── deployment/node_inventory.json
├── deployment/deployment_receipts.jsonl
├── operations/premarket_events.jsonl
├── operations/market_access_state.json
├── procedures/deployment_checklist.md
├── procedures/market_access_hold.md
├── procedures/incident_escalation.md
├── business/opening_constraints.md
├── simulator/initial_state.json
└── expected/golden_facts.json
```

Do not create a magic file that simply says “NODE 08 BAD; STOP.” The value comes from combining evidence, but the facts must be objectively recoverable.

Every evidence item should record:
- evidence ID;
- local source path;
- source hash;
- line/record locator;
- acquisition time;
- acquiring role;
- fact extracted.

Unsupported model prose can never satisfy the contract.
