# Backup case — cross-functional order exception

Situation:
- $2.4M strategic order;
- 72-hour deadline;
- 35% of product under quality hold;
- $180K/day late-delivery exposure;
- possible approved alternate source;
- no single SOP covers the combination.

Initial candidate: release held inventory.  
Falsifier: quality release criteria are not satisfied.  
Judge: `INSUFFICIENT_EVIDENCE`.

Missing:
- alternate supplier approval;
- split-delivery right;
- reallocation impact;
- expedite cost.

Second pass finds an approved supplier and split delivery, while the held lot remains prohibited.

Revised plan: 65% qualified stock + 35% approved alternate + expedite.

Deterministic rehearsal target:
- 100% fulfillment;
- zero quality violation;
- zero displaced priority order;
- $42K incremental cost;
- $540K avoided exposure;
- rollback PASS.

Human approval -> local SQLite ERP state change -> independent verification.
