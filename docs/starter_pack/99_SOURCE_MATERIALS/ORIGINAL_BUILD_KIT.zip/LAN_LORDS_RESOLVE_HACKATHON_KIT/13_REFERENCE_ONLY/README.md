# Reference-only files
These are user-provided/pre-event references. They are **not** the functioning hackathon agent. Use them for architectural lessons and visual direction. Build/finalize the runtime implementation on the event day and preserve transparent provenance.
