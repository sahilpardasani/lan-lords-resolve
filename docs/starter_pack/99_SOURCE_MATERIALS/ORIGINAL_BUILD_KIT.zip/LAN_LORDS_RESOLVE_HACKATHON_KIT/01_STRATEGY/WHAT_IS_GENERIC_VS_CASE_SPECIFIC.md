# What exactly are we mapping?

We are **not mapping one person's job**.

We are mapping a generic exception-resolution process where evidence, constraints and authority are fragmented.

## Layer 1 — Resolve Core: generic
- canonical case state;
- append-only journal;
- evidence references;
- budgets/capabilities;
- state transitions;
- retries/cancellation;
- rehearsal/admission;
- approval grant;
- commit/verification.

## Layer 2 — cognitive roles: generic
1. Evidence Scout
2. Operations/Technical Planner
3. Business Impact Analyst
4. Falsifier / Red Team
5. Judge

These are cognitive responsibilities, not departments.

## Layer 3 — Case Adapter: domain-specific
Defines:
- local evidence namespaces;
- tools;
- objective;
- candidate-action vocabulary;
- consequence/reversibility constraints;
- simulator;
- acceptance tests.

## Layer 4 — Demo Case: specific
The historical market-access replay is a case adapter. The same core can support an engineering release, manufacturing quality exception, cyber containment, supply-chain disruption or order exception.

Hackathon proof target:
**one generic runtime + one excellent primary case + one small backup case.**
