# Winning strategy

The goal is not maximum architecture. It is maximum **judge-visible value per minute of build risk**.

Priority order:
1. end-to-end demo works;
2. required NVIDIA stack is visibly and genuinely used;
3. local/zero-egress advantage is proven;
4. the business problem is instantly understandable;
5. UI/story is polished;
6. only then novel optimization.

## What judges should remember
> A real historical incident had 97 warning messages before a catastrophic transition. Resolve did not “predict the future”; it refused to turn fragmented, unexplained evidence into permission. It gathered the exact missing facts, isolated the mismatch, rehearsed a reversible hold, requested a human approval, changed local state and verified the outcome — all on one GB10.

## Sponsor mapping
- OpenClaw = actual agent runtime
- NemoClaw = lifecycle + inference route + agent configuration
- OpenShell = filesystem/process/network execution boundary
- GB10 = local inference/computation

Put these visibly in the UI status bar. Do not make them logos hidden on the last slide.
