# 12-hour timeline — one technical builder + one business/product teammate

Adapt the exact timestamps to the organizer's schedule. The **gates** matter more than the labels.

| Time | Phase | Technical owner | Product/business owner | Exit gate |
|---|---|---|---|---|
| 09:00–09:30 | P00 Hardware | SSD, local cable, GB10, disk, versions | confirm rules/submission fields | machine usable |
| 09:30–10:00 | P01 Kickoff | clean repo + baseline commit | case/story board | kickoff SHA recorded |
| 10:00–10:45 | P02 NVIDIA P0 | 1 validated local model + stack + one tool turn | 90-sec story | structured local tool loop PASS |
| 10:45–11:15 | P03 Zero egress | lock policy + negative egress test | capture proof | public blocked, local works |
| 11:15–12:00 | P04 Kernel | schemas, journal, state machine, budgets, cancel | validate labels | kernel pytest PASS |
| 12:00–12:45 | P05 Case | local synthetic case + simulator | own provenance/data consistency | case facts PASS |
| 12:45–13:30 | P06 First loop | Evidence + Planner + Business + Judge | usability test | DEFINE->JUDGE works |
| 13:30–13:45 | reset/food | no feature work | no feature work | aligned |
| 13:45–14:30 | P06b Red team | Falsifier + missing-evidence round | check story tension | unsafe first answer blocked |
| 14:30–15:15 | P07 Act safely | rehearse + admission + approval + commit + verify | approval/business metrics | backend golden path PASS |
| 15:15–16:00 | P08 UI | single HTML + SSE/fetch | copy/hierarchy | full live demo once |
| 16:00–16:30 | P09 First freeze | 3 runs + store replay + record video | record 90-sec take | backup exists |
| 16:30–17:15 | P10 P1 only | Bonsai/dual model/KV/concurrency A/B | judge perceived speed | keep only measured win |
| 17:15–17:45 | P11 Red team | failure injection + fallback + cancel | Q&A drill | P0 suite PASS |
| 17:45–18:00 | Submission | freeze SHA/config/hashes | submit | submission done |
| 18:00–19:30 | Pitch prep | crash fixes only | pitch/rehearsal | 5-min run <4:45 |
| 19:30–21:00 | Finals | operate live/fallback | tell story | no live debugging |

## Kill switches
- **10:45** custom model trouble -> validated NVIDIA model.
- **11:15** required stack tool loop not working -> all technical attention here.
- **13:30** agent fan-out unstable -> run logical roles sequentially.
- **15:15** backend incomplete -> stop UI polish/dual-model work.
- **16:00** no successful run -> simplify case immediately.
- **16:30** P0 feature freeze.
- **17:15** all optimization ends.

## CI/CD cadence
Every 20–30 minutes:
1. run focused tests;
2. run local `check` target;
3. manually inspect one representative journal;
4. commit one coherent increment;
5. record the SHA when a phase passes.

Keep risky dual-model/cache work on a reversible experiment branch after the P0 freeze.
