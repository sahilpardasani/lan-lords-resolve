# Team split: technical builder + business/product teammate

## You own
GB10, models, NemoClaw/OpenClaw/OpenShell, Python backend, tests, UI wiring, Git, zero-egress proof, demo operation.

## She owns
- rules/rubric tracking;
- historical source sheet;
- synthetic case-data consistency;
- business language/numbers;
- screen copy;
- 90-second submission cut;
- five-minute timing;
- judge-question log;
- backup replay/video operation.

## Her first 90 minutes
Ask her to return:
1. one-sentence problem;
2. one-sentence product;
3. five numbers/facts that matter;
4. five labels a nontechnical judge needs in the UI;
5. every historical claim she cannot defend from the SEC source;
6. ten likely judge questions.

This keeps her productive without making her learn the inference stack.
