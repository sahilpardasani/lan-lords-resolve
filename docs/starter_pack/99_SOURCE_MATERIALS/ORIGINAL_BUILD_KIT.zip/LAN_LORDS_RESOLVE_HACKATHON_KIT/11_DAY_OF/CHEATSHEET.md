# Day-of cheatsheet

First commands:
```bash
uname -m
nvidia-smi
docker info
df -h
free -h
python3 --version
git --version
```

Repo:
```bash
mkdir -p ~/lan-lords && cd ~/lan-lords
git init
git commit --allow-empty -m "hackathon kickoff"
```

Gate order:
`model -> required stack -> tool turn -> zero egress -> kernel -> case -> Judge -> evidence loop -> rehearsal -> approval -> commit -> verify -> UI -> replay -> video -> P1 optimization`

If stuck:
- custom model -> validated model;
- two models -> one;
- parallel roles -> sequential logical roles;
- React -> single HTML;
- live runtime -> real same-day replay;
- replay -> local recorded video.

Never: external runtime calls, model approval shopping, blind commit retry, unsupported historical claims, or new features after final freeze.
