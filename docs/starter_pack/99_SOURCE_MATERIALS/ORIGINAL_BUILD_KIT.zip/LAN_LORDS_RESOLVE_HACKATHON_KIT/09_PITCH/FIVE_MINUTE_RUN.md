# Five-minute run of show

**0:00–0:25** — `97 WARNINGS. NOBODY STOPPED THE SYSTEM.` Historical public incident pattern; synthetic local reconstruction.  
**0:25–0:45** — show countdown + `External calls 0` + sponsor-stack health.  
**0:45–1:30** — Evidence/Operations/Business; candidate `PROCEED + MONITOR`.  
**1:30–2:10** — Falsifier/Judge -> `INSUFFICIENT EVIDENCE`. Say: *Insufficient evidence doesn't mean ask the model again. It means get exactly what is missing.*  
**2:10–2:45** — node 08 old version; 97/97 anomalies correlate; `PROCEED + MONITOR — BLOCKED`.  
**2:45–3:25** — `HOLD -> ISOLATE -> REDEPLOY -> REPLAY`; rehearsal + Resolve Contract PASS/HUMAN.  
**3:25–3:50** — approve HOLD -> local state change -> `OUTCOME VERIFIED` -> WATCH MODE.  
**3:50–4:25** — architecture reveal: OpenClaw, NemoClaw, OpenShell, GB10, one/two local models.  
**4:25–4:50** — generalize to engineering/manufacturing/cyber/supply chain/finance.  
**4:50–5:00** — *SOPs handle the known path. Resolve handles what falls between them.*
