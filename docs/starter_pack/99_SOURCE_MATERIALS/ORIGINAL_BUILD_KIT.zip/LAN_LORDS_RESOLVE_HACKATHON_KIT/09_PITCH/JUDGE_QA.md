# Judge Q&A

**What is Resolve?**  
A zero-egress local decision team for high-impact exceptions that span multiple SOPs or organizational silos.

**Are you replacing a job?**  
No. We model a generic exception-resolution loop. Departments are evidence sources; agents have cognitive roles; a case adapter defines the domain.

**Why five agents?**  
Three independent investigations (evidence, technical feasibility, business impact), one adversarial reviewer and one independent Judge. Five is the smallest clean separation we wanted to demonstrate.

**Why not one agent with five prompts?**  
That is a valid reliability fallback. Product value comes from role separation and deterministic execution boundaries, not process count.

**Why two models?**  
Only if measured. FAST work is parallel/latency-sensitive; Red Team/Judge is less frequent and harder. The product works with one model.

**Is model 2 a safety vote?**  
No. Runtime/schema failure can fall back; disagreement lowers autonomy. We never ask models repeatedly until one approves.

**Why Bonsai?**  
Its reported ~7.2 GB 27B-class footprint is attractive for multiple fast local contexts. It remains optional because the custom CUDA path increases integration risk.

**Why the NVIDIA validated model?**  
Lowest sponsor-stack integration risk and a validated GB10/NemoClaw serving path with tool-oriented configuration.

**Why local?**  
The evidence is internal deployment state, procedures and business context. It stays on the workstation, and operation does not depend on a cloud model/API.

**Why GB10?**  
128 GB unified memory-class hardware lets the model(s), context, local state and tooling coexist on one workstation.

**What does OpenClaw do?**  
Actual agent runtime/roles/tools.

**What does NemoClaw do?**  
Sandbox lifecycle, agent configuration and local inference routing/health.

**What does OpenShell do?**  
Filesystem/process/network boundary. We explicitly prove public egress is blocked.

**Is it deterministic?**  
No. Model output is nondeterministic. State transitions, evidence rules, admission, approvals, retry semantics and verification are deterministic.

**What if evidence is insufficient?**  
Resolve names exact gaps and gathers only those facts, up to a bounded number of rounds. It does not repeat the consequential action.

**Does it execute?**  
Yes, in a synthetic local business simulator. Human approval changes canonical state; a separate verifier observes the result.

**Production ready?**  
No. This is a credible local MVP, not a production SaaS claim.

**What was built today?**  
Show the kickoff commit and phase-gated history.
