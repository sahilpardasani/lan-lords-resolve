# 90-second submission cut

0–08: `97 WARNINGS` + historical replay label.  
08–18: synthetic local company evidence; no external calls.  
18–32: 3 roles investigate; `PROCEED + MONITOR`.  
32–44: `INSUFFICIENT EVIDENCE`.  
44–58: node 08 mismatch + 97/97 anomaly correlation.  
58–67: initial candidate BLOCKED.  
67–77: bounded hold/isolate/redeploy/replay PASS.  
77–85: human approves; `OUTCOME VERIFIED`.  
85–90: `OpenClaw + NemoClaw + OpenShell | GB10 LOCAL | EXTERNAL CALLS 0 | LAN LORDS / Resolve`.
