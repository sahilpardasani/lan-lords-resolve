# Rules and provenance

## Prepare before the event
Plans, architecture diagrams, public case research, UI wireframes, schemas, interface contracts, test plans/templates, dependency caches, model files, source archives, container archives, offline docs and generic empty scaffolds.

## Build on the day
The functioning Resolve runtime, actual runtime prompts/skills, working orchestrator, case-tool wiring, evidence loop, Judge path, rehearsal/approval/commit/verification logic and final frontend-backend integration.

## Do not hide a prebuilt agent
Do not disguise executable implementation as “secret documentation.” Put pre-event material under a folder literally called `PRE_EVENT_ALLOWED_MATERIALS`. Transparency is safer and the rules already allow plans/scaffolds/libraries.

At kickoff:
1. create an empty repo;
2. make a timestamped empty commit;
3. record hardware/tool versions;
4. copy only permitted reference/scaffold material;
5. build the functioning agent after kickoff;
6. commit in small, auditable phase increments.

## Cloud coding assistants
Cursor/Codex/Claude Code are development tools, not part of Resolve. Confirm with organizers whether cloud coding assistants are permitted during development. If allowed, never wire them into Resolve or the final demo runtime. If “all inference local” is interpreted to cover development too, stop using them after kickoff.
