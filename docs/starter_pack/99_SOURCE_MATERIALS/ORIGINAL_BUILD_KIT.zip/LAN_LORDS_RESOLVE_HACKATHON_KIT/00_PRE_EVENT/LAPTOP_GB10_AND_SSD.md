# MacBook + Dell GB10 — simplest workflow

## Mental model
Your MacBook is the **editor/control machine**. The Dell Pro Max with GB10 is the **runtime machine**.

On the GB10 live:
- model server(s);
- NemoClaw/OpenClaw/OpenShell;
- Python backend;
- SQLite/local files;
- UI server;
- successful replay;
- recorded demo.

## Preferred connection: direct Ethernet
The Dell Pro Max with GB10 has a 10 GbE RJ-45 port. Bring:
- Ethernet cable;
- USB-C/Thunderbolt Ethernet adapter for the Mac;
- one spare cable if possible.

A direct cable removes venue Wi-Fi from the development loop.

Example private addresses:
- Mac: `192.168.50.1/24`
- GB10: `192.168.50.2/24`
- no gateway on this interface.

On GB10, first discover the real interface with `ip link`, then configure it. On Mac use System Settings -> Network -> adapter -> manual IPv4.

Test:
```bash
ssh <gb10-user>@192.168.50.2
```

## Cursor
Cursor supports Remote-SSH. If it works, open the repo **on the GB10** from your Mac. Cursor stays on the laptop; filesystem/terminal/runtime are on GB10.

If Remote-SSH burns more than ~10–15 minutes, stop troubleshooting it.

Fallback over the direct cable:
```bash
rsync -av --delete --exclude '.git' ./lan-lords/ <gb10-user>@192.168.50.2:~/lan-lords/
```
Keep `.git` canonical on the GB10.

## Final fallback: SSD shuttle
Edit on Mac -> tar the changed source -> copy via SSD -> extract to staging on GB10 -> diff -> copy into canonical repo -> test -> commit.

Never have both machines actively writing one Git repo on the removable disk.

## Demo independence rule
Before judging, unplug/ignore the Mac mentally. The GB10 alone must have everything needed to run live, replay a successful run, or play the recorded fallback.
