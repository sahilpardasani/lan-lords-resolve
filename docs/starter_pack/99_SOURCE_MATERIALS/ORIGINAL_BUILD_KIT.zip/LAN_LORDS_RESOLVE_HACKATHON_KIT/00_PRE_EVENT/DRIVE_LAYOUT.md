# External SSD layout

```text
LAN_LORDS_DRIVE/
├── PRE_EVENT_ALLOWED_MATERIALS/
├── STACK/
│   ├── source_archives/
│   ├── docker_images/
│   ├── linux_arm64_wheels/
│   └── offline_docs/
├── MODELS/
│   ├── nvidia_validated/
│   ├── bonsai/
│   └── qwen38/
├── CHECKSUMS/SHA256SUMS
├── HACKATHON_KIT/
└── EMPTY_REPO_SCAFFOLD/
```

Use exFAT only as a transfer layer if you need Mac + Linux compatibility. Do **not** make exFAT the canonical development filesystem: Unix permissions/symlinks and Git behavior are less reliable. Preserve source trees inside tar archives and copy/extract to the GB10 internal NVMe.

Before leaving, checksum every large asset. Example:

```bash
find . -type f -not -path './CHECKSUMS/*' -print0 | sort -z | xargs -0 shasum -a 256 > CHECKSUMS/SHA256SUMS
```

Never store Hugging Face, NGC, GitHub, Cursor or other credentials in this kit.
