# Offline dependency checklist

## Required stack
Bring pinned copies/artifacts for:
- NemoClaw
- OpenClaw
- OpenShell
- relevant offline NVIDIA docs
- exact version/SHA manifest

## Models
Bring at least:
1. P0 validated GB10/NemoClaw model artifacts;
2. Ternary Bonsai 27B if testing FAST lane;
3. one Qwen3.8 GGUF if testing a second/deep/fallback path.

## Python Linux ARM64 wheelhouse
Prepare wheels for the GB10 Python version:
- fastapi
- uvicorn
- pydantic
- httpx
- pytest
- pytest-asyncio
- ruff

Prefer a plain HTML/CSS/JS frontend for P0; it avoids a Node/npm critical path.

## Utilities
Have local installers/packages/source for anything not guaranteed on the GB10:
- jq
- ripgrep
- sqlite3 CLI
- git
- curl
- rsync
- tmux
- cmake/ninja/build-essential if compiling Bonsai's llama.cpp path.

## Container images
If the pinned NVIDIA path uses container images and licensing permits it, pre-pull the exact Linux/ARM64 images and `docker save` them. Record image digests. Do not rely on “latest.”
