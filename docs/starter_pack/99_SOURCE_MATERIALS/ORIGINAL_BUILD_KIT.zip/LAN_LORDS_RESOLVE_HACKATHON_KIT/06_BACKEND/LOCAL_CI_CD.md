# Local CI/CD compressed from Autonomous Labs lessons

The goal is continuous proof, not a complex CI service.

Every coherent increment:
```bash
ruff check .
pytest -q
python scripts/smoke.py
```
Then commit.

At each phase gate:
- tests pass;
- manually inspect one representative journal;
- save gate evidence;
- record SHA;
- keep last-known-good recoverable.

Recommended branches:
- `main` = only phase-gated code;
- `experiment/dual-model` = optional P1 work after P0 freeze.

Final release identity should record:
- source SHA;
- model IDs + hashes;
- NemoClaw/OpenShell/OpenClaw versions;
- runtime config hash;
- case-data hash;
- zero-egress policy hash.

Deployment target is one GB10. Rollback is checkout of last-known-good SHA + matching config, then smoke test.
