# Local tool contracts

No web/API tool exists in Resolve.

Read-only:
- `search_local(query,namespaces,limit)`
- `read_evidence(source,locator)`
- `inspect_node_version(node_id)`
- `correlate_anomalies(node_id=None)`
- `calculate_business_impact(inputs)`

Rehearsal:
- `simulate_hold_and_isolation(candidate)`
- `replay_premarket(candidate)`
- `rollback_test(candidate)`

Consequential local tool:
- `commit_candidate(candidate_fingerprint, approval_grant)`

Verification:
- `verify_outcome(expected_envelope)` reads actual post-action state.

Before tool admission:
- not cancelled;
- role permits tool;
- parameters validate;
- budget remains;
- consequence class allowed;
- exact approval present if required.
