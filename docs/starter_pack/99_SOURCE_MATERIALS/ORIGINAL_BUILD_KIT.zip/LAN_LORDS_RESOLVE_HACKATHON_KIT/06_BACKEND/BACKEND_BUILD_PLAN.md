# Backend build plan

P0: Python + FastAPI + SQLite + JSONL journal + supported NemoClaw CLI/subprocess adapter + static HTML + SSE.

Create on the day:
```text
resolve/
├── schemas.py
├── journal.py
├── state_machine.py
├── evidence.py
├── model_runtime.py
├── agents.py
├── orchestrator.py
├── budgets.py
├── rehearsal.py
├── admission.py
├── approval.py
├── verifier.py
└── case_adapter.py
```

Build order:
1. schemas;
2. journal;
3. legal state transitions;
4. case adapter;
5. one model turn;
6. role invocation;
7. evidence packet;
8. Judge;
9. missing-evidence loop;
10. rehearsal;
11. admission;
12. approval;
13. commit;
14. verification;
15. SSE API;
16. UI wiring.
