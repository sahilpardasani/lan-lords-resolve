# LAN LORDS / Resolve — Start Here

**Team:** LAN LORDS  
**Product:** Resolve  
**Thesis:** **SOPs handle the known path. Resolve handles the exceptions between them.**

This kit is a planning, test-contract, installation and execution runbook. It is intentionally **not a finished agent**.

## What Resolve is
Resolve is a general exception-resolution runtime. It is not a trading agent, not a finance employee replacement, and not a clone of Autonomous Labs.

The generic loop is:

`Objective -> local evidence -> parallel analysis -> candidate -> falsifier -> Judge -> targeted missing evidence -> rehearsal -> Resolve Contract -> human approval when needed -> local commit -> verification -> watch/close`

The publicly documented 2012 market-access incident is only the **primary demo case adapter**. The backup case is a cross-functional customer-order/quality exception.

## P0 before cleverness
Build in this order:
1. one stable local model;
2. NemoClaw + OpenClaw + OpenShell actually working;
3. zero-egress proof;
4. deterministic journal/state/admission kernel;
5. one complete case;
6. one full backend golden run;
7. one polished one-page UI;
8. replay + recorded backup;
9. only then Bonsai, second model, parallelism and KV tuning.

## Four demo levels
A. Two-model live Resolve  
B. One-model live Resolve  
C. Replay of a real successful run created on the GB10 that day  
D. Local screen recording of that successful GB10 run

Never present C or D as live.

## Read first
- `01_STRATEGY/12_HOUR_TIMELINE.md`
- `00_PRE_EVENT/LAPTOP_GB10_AND_SSD.md`
- `04_MODELS/GB10_FIRST_45_MINUTES.md`
- `01_STRATEGY/WHAT_IS_GENERIC_VS_CASE_SPECIFIC.md`
- `02_CASE/PRIMARY_HISTORICAL_REPLAY.md`
- `03_ARCHITECTURE/RESOLVE_CONTRACT.md`
- `08_QA/PHASE_GATE_MATRIX.csv`
- `09_PITCH/JUDGE_QA.md`
