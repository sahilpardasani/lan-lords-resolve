# Zero-egress proof

NemoClaw/OpenShell is deny-by-default, but the OpenClaw baseline can include explicitly allowed public endpoints. Therefore “Restricted” alone is not equivalent to zero egress.

Before the final demo:
- Restricted tier;
- web search disabled;
- remove/exclude public NVIDIA hosted endpoint if not needed;
- remove/exclude ClawHub/OpenClaw docs/service/npm baseline egress if not needed;
- no messaging endpoints;
- no cloud model credentials in runtime;
- local inference healthy;
- at least two public requests from the sandbox fail;
- a local inference/tool turn succeeds immediately after;
- export/save the live policy and doctor/status output.

UI badge rule: show **ZERO EGRESS VERIFIED** only after this exact build passes the negative and positive tests.
