# Dual-model / fallback policy

Model 2 has three legitimate uses:

1. **FAST/DEEP specialization** — routine evidence/planning vs infrequent hard red-team/judging.
2. **Runtime fallback** — timeout, crash, failed health check or repeated schema failure.
3. **Semantic-stagnation challenge** — another model tries to falsify a repeated unsupported hypothesis using the same evidence packet.

## Never approval-shop
Wrong:
`Judge A BLOCKED -> ask Judge B -> Judge B ADMISSIBLE -> execute`

Correct:
`model disagreement -> conflict -> more evidence or human review -> re-evaluate`

If the designated Judge runtime is unavailable, consequential commit stops unless a previously tested/configured fallback exists. A model outage never increases autonomy.
