# GB10 first 45 minutes

## 0–5: machine facts
```bash
uname -a
uname -m
nvidia-smi
docker version
docker info
df -h
free -h
python3 --version
git --version
```
Save to `evidence/preflight.txt`.

## 5–10: copy SSD to internal NVMe
```bash
mkdir -p ~/lanlords-assets ~/lan-lords
rsync -av /media/$USER/<DRIVE>/MODELS/ ~/lanlords-assets/models/
rsync -av /media/$USER/<DRIVE>/STACK/ ~/lanlords-assets/stack/
```

## 10–20: required stack health
Use the pinned artifacts you brought. Check `nemoclaw --help`, `openshell --help`, Docker, and the intended model route.

## 20–35: one model, one OpenClaw tool turn
The exit condition is not “server started.” It is:
`agent -> local model -> structured local tool -> tool result -> agent response`.

Check:
```bash
nemoclaw <sandbox> status
nemoclaw <sandbox> doctor
```

## 35–45: zero egress
Choose Restricted, remove/exclude unnecessary baseline public entries, disable web search, prove public access fails, then prove local inference still succeeds.

Only then set/display `ZERO_EGRESS_VERIFIED=true`.
