# Model strategy

## P0 — validated NVIDIA route first
As of 2026-08-21, NVIDIA documents the single-DGX-Spark/GB10 managed vLLM default as `nvidia/Qwen3.6-35B-A3B-NVFP4`. The profile is designed for the hardware and includes structured-tool configuration plus serving optimizations such as prefix caching/chunked prefill/async scheduling.

Use this or the exact validated profile present on the event machine as your reliability baseline.

## P1 FAST — Ternary Bonsai 27B
Attractive because its publisher reports ~7.2 GB deployed weights and a 262K context-capable architecture. It uses custom low-bit llama.cpp CUDA/Metal kernels.

Risk: custom CUDA/ARM64 path is additional integration surface. Timebox it hard.

## P1 alternate DEEP — Qwen3.8 27B GGUF
Test only if it measurably improves Falsifier/Judge behavior or gives a useful fallback.

## Two models must earn their complexity
Do not pitch “two because they fit.” Pitch only a measured outcome: lower end-to-end case time, higher structured-output success, or materially better adversarial/Judge behavior.

The product must remain functional with one model.
