# Model installation in very simple English

A model file is mostly not “installed.” You **download it before the event, copy it to the GB10, then start a local server that opens it**.

## Before event: Bonsai
Publisher's current path uses its llama.cpp fork and the GGUF:

```bash
git clone https://github.com/PrismML-Eng/llama.cpp
# record SHA and archive the source to SSD
hf download prism-ml/Ternary-Bonsai-27B-gguf   Ternary-Bonsai-27B-Q2_0.gguf   --local-dir /Volumes/<DRIVE>/MODELS/bonsai
```

## Before event: Qwen3.8
Download exactly one chosen GGUF quantization from `unsloth/Qwen3.8-27B-GGUF` to avoid wasting disk. Keep it optional.

## On GB10: copy files
```bash
mkdir -p ~/lanlords-assets/models
cp -av /media/$USER/<DRIVE>/MODELS/* ~/lanlords-assets/models/
```

## Bonsai server on GB10
Build the publisher's CUDA fork:
```bash
cmake -B build -DGGML_CUDA=ON
cmake --build build -j
```
Then start the local server:
```bash
./build/bin/llama-server   -m ~/lanlords-assets/models/bonsai/Ternary-Bonsai-27B-Q2_0.gguf   --host 127.0.0.1 --port 11434 -ngl 99
```
Test:
```bash
curl http://127.0.0.1:11434/v1/models
```

## Qwen3.8 GGUF
Use a compatible current llama.cpp build:
```bash
llama-server -m ~/lanlords-assets/models/qwen38/<file.gguf>   --host 127.0.0.1 --port 11435 -ngl 99
```

Do **not** add huge context/concurrency/cache tuning until baseline chat + structured tool behavior works.
