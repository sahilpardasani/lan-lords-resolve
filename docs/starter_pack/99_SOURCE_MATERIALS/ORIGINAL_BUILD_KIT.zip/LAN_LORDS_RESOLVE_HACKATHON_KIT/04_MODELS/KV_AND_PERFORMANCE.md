# KV cache / parallelism optimization

Optimize only after a successful P0 run has been recorded.

Primary metric: **golden-case end-to-end wall time**.

Also measure:
- TTFT;
- output tok/s;
- peak memory;
- queue wait;
- schema success;
- tool-call success;
- Judge disposition stability.

Order:
1. validated default baseline, 3 runs;
2. FAST concurrency 1 vs 2 vs 3;
3. reduce context by passing compact evidence packets/references instead of full chat histories;
4. only on custom llama.cpp, A/B default/f16 vs q8 KV, then q4 if supported;
5. keep a shared stable prompt prefix for better prefix/KV reuse;
6. stop.

Do not spend the hackathon on speculative decoding. With 128 GB memory, correctness and wall-clock demo completion matter more than shaving memory at all costs.
