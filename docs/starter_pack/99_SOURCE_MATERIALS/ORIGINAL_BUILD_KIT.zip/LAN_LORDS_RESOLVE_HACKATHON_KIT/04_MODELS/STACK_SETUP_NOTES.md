# NemoClaw + OpenClaw + OpenShell setup notes

Current NVIDIA design:
- the agent uses `inference.local` inside the sandbox;
- OpenShell routes that traffic to the configured local endpoint;
- NemoClaw manages onboarding, lifecycle, status/doctor and agent configuration.

P0 local vLLM patterns documented by NVIDIA include:
```bash
NEMOCLAW_PROVIDER=vllm nemoclaw onboard --non-interactive
```
or a managed local install path on supported hardware. Use the exact pinned release/artifacts on your drive and do not trigger downloads at the venue unless explicitly necessary/allowed.

For a custom local OpenAI-compatible endpoint (llama.cpp/vLLM), NVIDIA documents a `custom` provider path using a localhost endpoint. Use the exact environment-variable names supported by your pinned release.

NemoClaw also supports a checked-in `agents.yaml` for primary/secondary OpenClaw agents and a non-interactive `nemoclaw <sandbox> agent ...` path suitable for a backend/evaluation harness.

P0: one sandbox/model.  
P1 dual: consider two named sandboxes, FAST and DEEP, rather than inventing a network router before the product works.
