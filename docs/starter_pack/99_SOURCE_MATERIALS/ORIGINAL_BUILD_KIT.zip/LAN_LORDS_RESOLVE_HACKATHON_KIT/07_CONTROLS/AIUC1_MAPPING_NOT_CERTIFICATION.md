# AIUC-1 mapping — not certification

Never write `AIUC-1 compliant` or `AIUC-1 certified` for the hackathon prototype.

Use: **Illustrative AIUC-1 control alignment — not certification**.

Only show implemented controls:
- OpenShell sandbox/zero-egress -> B006-style unauthorized-action/execution safeguards;
- tool allowlist/parameter validation -> D003.1;
- budgets/caps -> D003.2;
- tool journal -> D003.3;
- human approval -> D003.4 / high-risk human review concepts;
- full agent/tool/approval journal -> E015;
- cancel/intervention -> C009 concepts;
- adversarial tests -> agentic security testing concepts.

A real audit/certification needs a defined scope and much more evidence.
