# Autonomous Labs learnings applied to Resolve

Keep:
- deterministic governance around nondeterministic model computation;
- one canonical journal;
- one canonical state machine;
- capability/budget/cancel checks before admission;
- evidence separate from interpretation;
- bounded retry classes;
- reversibility;
- exact approval for consequential actions;
- commit followed by verification;
- one canonical rule + many consumers.

Simplify away for the hackathon:
- multi-tenancy;
- production identity;
- remote providers;
- watches/schedules framework;
- distributed queues;
- production backup/HA;
- production observability stack.

Hackathon invariants to prove:
1. no evidence ID -> claim cannot satisfy contract;
2. BLOCKED/INSUFFICIENT cannot commit;
3. missing evidence never increases autonomy;
4. agent cannot grant itself capability;
5. approval exact + expiring + one-time;
6. candidate mutation invalidates approval;
7. cancellation prevents later admission;
8. unknown effects reconcile, never blind retry;
9. UI is a journal projection;
10. verifier observes actual post-action state.
