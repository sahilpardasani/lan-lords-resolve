# Runtime state machine

```text
CREATED -> DEFINED -> FAST_FANOUT -> RED_TEAM -> JUDGING
  JUDGING -> BLOCKED -> CLOSED
  JUDGING -> INSUFFICIENT_EVIDENCE -> EVIDENCE_ROUND -> JUDGING
  JUDGING -> ADMISSIBLE -> REHEARSING -> ADMISSION_CHECK
      -> WAITING_APPROVAL (when required)
      -> COMMITTING -> VERIFYING -> WATCHING/CLOSED
```

Tests must reject illegal transitions including:
- CREATED -> COMMITTING;
- BLOCKED -> COMMITTING;
- INSUFFICIENT_EVIDENCE -> COMMITTING;
- WAITING_APPROVAL -> COMMITTING without exact valid grant;
- CANCELLED -> any new model/tool admission;
- VERIFYING -> COMMITTING as an implicit retry.

Cancellation is durable. Unknown commit outcomes enter reconciliation rather than repeat execution.
