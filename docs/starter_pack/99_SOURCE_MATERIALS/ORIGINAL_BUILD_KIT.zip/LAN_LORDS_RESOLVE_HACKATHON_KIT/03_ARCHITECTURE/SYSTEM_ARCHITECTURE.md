# System architecture

```text
Browser UI
   |
local HTTP + SSE
   |
Resolve Orchestrator  <-- only canonical writer
   |
   +--> Evidence Scout
   +--> Operations Planner
   +--> Business Impact
   +--> Falsifier
   +--> Judge
   |
Resolve Contract
   |
Deterministic rehearsal
   |
Human approval when required
   |
Local commit
   |
Independent verification
```

Platform path:

```text
Resolve backend
 -> NemoClaw named sandbox(es)
 -> OpenClaw agent runtime
 -> OpenShell boundary
 -> inference.local
 -> local model server on GB10
```

P0: one sandbox, one stable validated model.  
P1: optionally two named sandboxes/routes: FAST/Bonsai and DEEP/validated-Qwen-or-Qwen3.8.

Agents never choose their own model. Routing is deterministic.
