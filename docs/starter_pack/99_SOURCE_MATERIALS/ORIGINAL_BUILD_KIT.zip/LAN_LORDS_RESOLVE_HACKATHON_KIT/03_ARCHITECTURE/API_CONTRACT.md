# Minimal local API

- `POST /api/runs`
- `GET /api/runs/{run_id}`
- `GET /api/runs/{run_id}/events` (SSE)
- `POST /api/runs/{run_id}/approve`
- `POST /api/runs/{run_id}/cancel`
- `POST /api/runs/{run_id}/replay`
- `GET /api/runtime`
- `GET /api/health`

UI events are canonical projections, e.g.:

```json
{"seq":21,"event_type":"AGENT_STARTED","payload":{"agent_id":"evidence"}}
{"seq":31,"event_type":"JUDGE_RESULT","payload":{"disposition":"INSUFFICIENT_EVIDENCE","gaps":["node_08_version","anomaly_origin"]}}
{"seq":44,"event_type":"REHEARSAL_PASS","payload":{"checks":6}}
{"seq":50,"event_type":"APPROVAL_REQUIRED","payload":{"candidate_fingerprint":"..."}}
{"seq":56,"event_type":"OUTCOME_VERIFIED","payload":{"state":"WATCHING"}}
```

The browser must not invent live state. Replay mode may play a stored journal and must visibly say REPLAY.
