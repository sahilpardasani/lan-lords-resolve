# Resolve Contract

A candidate does not become executable because a model sounds confident.

Visible gates:
1. **Evidence** — sufficient, source-linked facts?
2. **Authority** — exact action allowed; human needed?
3. **Consequence** — blast radius and downside understood?
4. **Reversibility** — can we return to known state?
5. **Rehearsal** — deterministic local checks passed?
6. **Verification** — what observation proves the approved action worked?

Judge output is only:
- `ADMISSIBLE`
- `BLOCKED`
- `INSUFFICIENT_EVIDENCE`

The Judge never executes and never grants authority.

## Critical invariant
**Missing evidence must never increase autonomy.**

`INSUFFICIENT_EVIDENCE` -> exact gap list -> bounded evidence tasks -> append evidence -> re-evaluate. Maximum two evidence rounds.

If still unresolved: read-only, rehearse-only, smaller separately admissible action, human escalation, or preserve state.

## Retry classes
- `MODEL_FORMAT_ERROR` -> bounded inference retry / tested model fallback.
- `INSUFFICIENT_EVIDENCE` -> acquire new information; do not ask the same unchanged question repeatedly.
- `REHEARSAL_FAILED` -> revise/block candidate.
- `UNKNOWN_COMMIT_OUTCOME` -> reconcile/verify; never blindly repeat the effect.
