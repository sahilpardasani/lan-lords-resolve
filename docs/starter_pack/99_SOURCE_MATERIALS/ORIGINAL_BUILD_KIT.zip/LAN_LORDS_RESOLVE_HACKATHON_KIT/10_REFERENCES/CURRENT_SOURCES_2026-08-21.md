# Current source list checked 2026-08-21

NVIDIA NemoClaw quickstart: https://docs.nvidia.com/nemoclaw/latest/user-guide/openclaw/get-started/quickstart  
Local inference choices: https://docs.nvidia.com/nemoclaw/latest/user-guide/openclaw/inference/local-inference/choose-local-inference-server  
Custom endpoint: https://docs.nvidia.com/nemoclaw/latest/user-guide/openclaw/inference/custom-endpoints/set-up-openai-compatible-endpoint  
Network policies: https://docs.nvidia.com/nemoclaw/latest/reference/network-policies.html  
Declarative agents: https://docs.nvidia.com/nemoclaw/user-guide/openclaw/configure-agents/declarative-agents-manifest  
CLI: https://docs.nvidia.com/nemoclaw/latest/user-guide/openclaw/reference/commands  
DGX Spark hardware: https://docs.nvidia.com/dgx/dgx-spark/hardware.html  
Dell Pro Max GB10: https://www.dell.com/en-us/shop/desktop-computers/dell-pro-max-with-gb10/spd/dell-pro-max-fcm1253-micro/xcto_fcm1253_usx  
Dell initial setup: https://www.dell.com/support/kbdoc/en-us/000398800/dell-pro-max-with-gb-10-fcm1253-initial-setup-out-of-the-box-experience  
Cursor Remote SSH: https://docs.cursor.com/en/guides/advanced/datascience  
Bonsai: https://huggingface.co/prism-ml/Ternary-Bonsai-27B-gguf  
Qwen3.8 GGUF: https://huggingface.co/unsloth/Qwen3.8-27B-GGUF  
SEC case: https://www.sec.gov/newsroom/press-releases/2013-222  
SEC order: https://www.sec.gov/files/litigation/admin/2013/34-70694.pdf  
AIUC-1 B006: https://www.aiuc-1.com/security/enforce-contextual-access-controls  
AIUC-1 D003: https://www.aiuc-1.com/reliability/restrict-unsafe-tool-calls  
AIUC-1 E015: https://www.aiuc-1.com/accountability/log-model-activity
