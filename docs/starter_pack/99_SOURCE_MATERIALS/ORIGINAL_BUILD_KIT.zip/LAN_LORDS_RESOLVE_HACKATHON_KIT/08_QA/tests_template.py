"""Acceptance-test skeleton. Copy into the day-of repo and unskip as each P0 capability is implemented."""
import pytest

@pytest.mark.skip(reason="implement day-of")
def test_blocked_candidate_cannot_commit(): pass

@pytest.mark.skip(reason="implement day-of")
def test_insufficient_evidence_cannot_commit(): pass

@pytest.mark.skip(reason="implement day-of")
def test_missing_evidence_creates_targeted_tasks_not_action_retry(): pass

@pytest.mark.skip(reason="implement day-of")
def test_cancel_prevents_later_admission(): pass

@pytest.mark.skip(reason="implement day-of")
def test_approval_bound_to_candidate_fingerprint(): pass

@pytest.mark.skip(reason="implement day-of")
def test_approval_one_time(): pass

@pytest.mark.skip(reason="implement day-of")
def test_unknown_commit_reconciled_not_retried(): pass

@pytest.mark.skip(reason="implement day-of")
def test_unsupported_claim_not_contract_evidence(): pass

@pytest.mark.skip(reason="implement day-of")
def test_replay_makes_no_model_calls(): pass

@pytest.mark.skip(reason="implement day-of")
def test_public_egress_blocked(): pass
