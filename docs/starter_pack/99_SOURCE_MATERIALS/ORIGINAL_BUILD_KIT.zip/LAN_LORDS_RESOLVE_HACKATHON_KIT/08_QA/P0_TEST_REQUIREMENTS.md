# P0 test requirements

## Unit
state transitions; event sequence; evidence validation; budgets; cancel; candidate fingerprint; approval expiry/one-time use; tool allowlist; parameter validation.

## Integration
one local OpenClaw tool turn; DEFINE->JUDGE; INSUFFICIENT->evidence round->re-JUDGE; rehearsal; approval->commit->verify; BLOCKED cannot commit; replay requires no model.

## Negative
malformed model output; unsupported claim; missing evidence; stale approval; wrong action params; duplicate approval/commit; model timeout; tool timeout; cancel during work.

## Security/runtime
public egress blocked; local inference works; no cloud model key required; local tools cannot escape allowed case data root.

## Demo reliability
primary case 3 consecutive successful runs; replay loads; video exists; one-model fallback works if dual-model mode is used.

Final gate: no critical P0 test skipped.
