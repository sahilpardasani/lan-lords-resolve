# UI/UX spec

Visual language: Refiant/ADMIT-inspired Helvetica Neue/Helvetica/Arial, black/white/soft gray, muted mint for controlled/good states, restrained warning/red, monospace metadata, large clear type.

## Header
`LAN LORDS / Resolve`  
`OpenClaw HEALTHY | NemoClaw HEALTHY | OpenShell ZERO EGRESS | GB10 LOCAL | External calls 0`

## Layout
```text
+------------------+------------------------------+------------------+
| OBJECTIVE        | DECISION ROOM                | LOCAL EVIDENCE   |
| 97 warnings      | 5 logical roles              | DEPLOYMENT       |
| countdown        | current proposal             | OPERATIONS       |
| consequence      | Judge disposition            | PROCEDURES       |
|                  | Resolve Contract             | BUSINESS         |
+------------------+------------------------------+------------------+
| CANONICAL JOURNAL / RUNTIME HEALTH                                  |
+---------------------------------------------------------------------+
```

Critical sequence:
1. `PROCEED + MONITOR`
2. Red Team activates
3. `INSUFFICIENT EVIDENCE`
4. exact gaps
5. second-pass tasks
6. node 08 mismatch + anomaly correlation
7. `BLOCKED`
8. safe candidate
9. rehearsal PASS
10. `HUMAN APPROVAL REQUIRED`
11. approve
12. `OUTCOME VERIFIED`
13. `WATCH MODE`

If one model is used, label all roles LOCAL. Never fake dual-model routing.

Replay mode must show `REPLAY OF SUCCESSFUL GB10 RUN`.
