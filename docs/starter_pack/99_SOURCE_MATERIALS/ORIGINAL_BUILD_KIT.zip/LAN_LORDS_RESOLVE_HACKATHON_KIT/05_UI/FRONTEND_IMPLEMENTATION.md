# Frontend implementation

For a one-person build, P0 is **one HTML/CSS/JS page**, not React.

Use browser-native:
- `EventSource` for SSE;
- `fetch` for start/approve/cancel/replay;
- CSS for animation/state.

The backend can serve the static file. This removes npm/Vite/build failures from the critical path.

Frontend state is a projection of `/api/runs/{id}` plus canonical events. It does not contain a second live state machine.

Modes:
- `live` -> real model/tool runtime;
- `replay` -> stored journal from an actual successful same-day GB10 run with a visible banner.

Approval sends run ID + exact candidate fingerprint + approver label. Backend rejects stale, expired or consumed grants.
